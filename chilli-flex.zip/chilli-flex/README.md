# Chilli Flex 🌶️

Custom Netflix-style media app for your Jellyfin server. React Native + Expo, built for sideloading onto an Android box.

## Project structure

```
chilli-flex/
├── App.js                       # Main entry, navigation setup
├── app.config.js                # Expo config (allows HTTP for LAN)
├── package.json                 # Dependencies
├── theme/
│   └── colors.js                # Chilli red/orange palette + spacing
├── services/
│   └── jellyfinApi.js           # Jellyfin REST client
├── components/
│   ├── HeroCarousel.js          # Featured content swipeable hero
│   └── MediaRow.js              # Horizontal scrolling row + cards
└── screens/
    ├── HomeScreen.js            # Hero + Continue Watching + library rows
    ├── SearchScreen.js          # Live search across the library
    ├── NewsScreen.js            # "Just added" feed (your news tab)
    ├── DetailScreen.js          # Movie/show detail page
    └── SettingsScreen.js        # Server URL + API key config
```

## Setup (do this first)

Install Node.js if you haven't already, then:

```bash
# 1. Create a fresh Expo project (creates the boilerplate, assets, babel config etc)
npx create-expo-app chilli-flex
cd chilli-flex

# 2. Replace the generated files with the ones from this bundle
# (Drop App.js, package.json, app.config.js into root, copy theme/, services/, components/, screens/ folders)

# 3. Install all the dependencies
npm install @react-navigation/native @react-navigation/native-stack @react-navigation/bottom-tabs
npm install react-native-screens react-native-safe-area-context
npm install @react-native-async-storage/async-storage
npm install expo-linear-gradient @expo/vector-icons

# 4. Start the dev server
npx expo start
```

Scan the QR code with the Expo Go app on your phone — the app will load and run live with hot reload.

## Connecting to your Jellyfin server

Once Jellyfin is set up at home:

1. Open Chilli Flex → it'll show "Server not configured"
2. Tap Settings, enter:
   - **Server URL**: `http://YOUR_LOCAL_IP:8096` (e.g. `http://192.168.1.50:8096`)
   - **API Key**: Generate in Jellyfin Dashboard → API Keys → New
   - **User ID**: Find in Jellyfin Dashboard → Users → click user → copy UUID from URL
3. Hit Connect

## Building the APK for your Android box

```bash
# Install EAS CLI globally
npm install -g eas-cli

# Login (free Expo account)
eas login

# Configure the build
eas build:configure

# Build a preview APK (no Play Store needed)
eas build -p android --profile preview
```

EAS builds in the cloud and gives you a download link. Transfer the APK to USB, plug into the Android box, install, done.

## Design system

- **Background**: `#0A0A0A` deep black
- **Chilli accent**: `#FF3D2E` primary, `#FFA52C` ember orange highlight
- **Typography**: Bold display weights, tight letterspacing on titles
- **Pattern**: Section labels have a small chilli-red accent bar (the `titleAccent` in MediaRow)

## What's in the box

- ✅ Three-tab navigation (Home / Search / News)
- ✅ Hero carousel with swipe + dot indicators
- ✅ Horizontal media rows with progress bars for Continue Watching
- ✅ Live search with debouncing
- ✅ "Just added" news feed with featured first card
- ✅ Detail page with metadata, genres, cast
- ✅ Settings flow for Jellyfin connection
- ✅ Persistent server config via AsyncStorage

## What's not done yet (next steps)

- Video playback — need to add `expo-av` or `react-native-video` and wire up `streamUrl()`
- Custom fonts — load Bebas Neue / Inter via `expo-font` for the display look
- App icon and splash screen assets — drop into `/assets/`
- Episode browser for TV shows in DetailScreen
- "My List" persistence (currently just logs)
- Push notifications when new content is added (the news feed feature)

## Testing tips

- For development on phone: install Expo Go, scan QR from `npx expo start`
- For Android box testing: build the preview APK and sideload
- Local server URL must be reachable from your phone — same WiFi network
