// Jellyfin API client for Chilli Flex
// Plug in your server URL and API key when Jellyfin is running at home

import AsyncStorage from '@react-native-async-storage/async-storage';

class JellyfinAPI {
  constructor() {
    this.serverUrl = null;
    this.apiKey = null;
    this.userId = null;
  }

  async init() {
    // Load saved config from device storage
    this.serverUrl = await AsyncStorage.getItem('jellyfin_server_url');
    this.apiKey = await AsyncStorage.getItem('jellyfin_api_key');
    this.userId = await AsyncStorage.getItem('jellyfin_user_id');
  }

  async configure({ serverUrl, apiKey, userId }) {
    this.serverUrl = serverUrl.replace(/\/$/, ''); // strip trailing slash
    this.apiKey = apiKey;
    this.userId = userId;

    await AsyncStorage.setItem('jellyfin_server_url', this.serverUrl);
    await AsyncStorage.setItem('jellyfin_api_key', this.apiKey);
    await AsyncStorage.setItem('jellyfin_user_id', this.userId);
  }

  isConfigured() {
    return !!(this.serverUrl && this.apiKey && this.userId);
  }

  headers() {
    return {
      'X-Emby-Token': this.apiKey,
      'Content-Type': 'application/json',
    };
  }

  async _fetch(path, params = {}) {
    if (!this.isConfigured()) {
      throw new Error('Jellyfin not configured. Set server URL and API key.');
    }
    const query = new URLSearchParams(params).toString();
    const url = `${this.serverUrl}${path}${query ? '?' + query : ''}`;
    const res = await fetch(url, { headers: this.headers() });
    if (!res.ok) throw new Error(`Jellyfin error ${res.status}: ${res.statusText}`);
    return res.json();
  }

  // Get featured / latest items for hero carousel
  async getFeatured(limit = 5) {
    const data = await this._fetch(`/Users/${this.userId}/Items/Latest`, {
      Limit: limit,
      Fields: 'Overview,Genres,PrimaryImageAspectRatio',
      EnableImageTypes: 'Backdrop,Primary,Logo',
    });
    return data;
  }

  // Continue watching
  async getContinueWatching(limit = 12) {
    const data = await this._fetch(`/Users/${this.userId}/Items/Resume`, {
      Limit: limit,
      Recursive: true,
      Fields: 'PrimaryImageAspectRatio',
      MediaTypes: 'Video',
    });
    return data.Items || [];
  }

  // Get recently added by category
  async getLatestByCategory(parentId, limit = 20) {
    const data = await this._fetch(`/Users/${this.userId}/Items/Latest`, {
      Limit: limit,
      ParentId: parentId,
      Fields: 'PrimaryImageAspectRatio',
    });
    return data;
  }

  // Get all libraries (Movies, Shows, etc)
  async getLibraries() {
    const data = await this._fetch(`/Users/${this.userId}/Views`);
    return data.Items || [];
  }

  // Search across the whole library
  async search(query, limit = 30) {
    const data = await this._fetch(`/Users/${this.userId}/Items`, {
      SearchTerm: query,
      Limit: limit,
      Recursive: true,
      IncludeItemTypes: 'Movie,Series,Episode',
      Fields: 'Overview,Genres,PrimaryImageAspectRatio',
    });
    return data.Items || [];
  }

  // Get single item details
  async getItem(itemId) {
    return this._fetch(`/Users/${this.userId}/Items/${itemId}`);
  }

  // Build image URL helpers
  imageUrl(itemId, type = 'Primary', opts = {}) {
    if (!itemId) return null;
    const params = new URLSearchParams({
      maxHeight: opts.maxHeight || 600,
      quality: opts.quality || 90,
      ...(opts.tag && { tag: opts.tag }),
    });
    return `${this.serverUrl}/Items/${itemId}/Images/${type}?${params}`;
  }

  backdropUrl(itemId, opts = {}) {
    return this.imageUrl(itemId, 'Backdrop', { maxHeight: 1080, ...opts });
  }

  // Stream URL for playback
  streamUrl(itemId) {
    return `${this.serverUrl}/Videos/${itemId}/stream?api_key=${this.apiKey}&Static=true`;
  }

  // Recently added "news feed" items - newest across all libraries
  async getNewsFeed(limit = 25) {
    const data = await this._fetch(`/Users/${this.userId}/Items/Latest`, {
      Limit: limit,
      Fields: 'Overview,DateCreated,Genres',
      EnableImageTypes: 'Primary,Backdrop',
    });
    return Array.isArray(data) ? data : (data.Items || []);
  }
}

export const jellyfin = new JellyfinAPI();
