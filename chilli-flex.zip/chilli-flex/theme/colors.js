// Chilli Flex theme - dark base with chilli red/orange accents
export const colors = {
  // Backgrounds
  bg: '#0A0A0A',           // primary background
  bgElevated: '#141414',   // cards, raised surfaces
  bgOverlay: 'rgba(10, 10, 10, 0.75)',

  // Chilli accents
  chilli: '#FF3D2E',       // primary accent - chilli red
  chilliDeep: '#D62828',   // pressed/darker variant
  chilliGlow: '#FF6B3D',   // hover/lighter variant
  ember: '#FFA52C',        // secondary orange highlight

  // Text
  text: '#FFFFFF',
  textDim: '#B3B3B3',
  textMuted: '#7A7A7A',

  // Utility
  border: '#1F1F1F',
  borderActive: '#FF3D2E',
  divider: 'rgba(255, 255, 255, 0.08)',

  // Buttons
  btnPrimary: '#FFFFFF',       // Netflix-style white play button
  btnPrimaryText: '#0A0A0A',
  btnSecondary: 'rgba(255, 255, 255, 0.18)',
  btnSecondaryText: '#FFFFFF',

  // Progress bar (chilli themed)
  progressBg: 'rgba(255, 255, 255, 0.2)',
  progressFill: '#FF3D2E',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 20,
  pill: 999,
};

export const typography = {
  // Use Bebas Neue or Oswald for display (more character than Inter/Roboto)
  // Use Inter for body since it's clean for content metadata
  // You'll load these via expo-font in App.js
  display: 'BebasNeue',
  body: 'Inter',
  bodyBold: 'Inter-Bold',
};
