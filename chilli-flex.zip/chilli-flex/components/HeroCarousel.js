import React, { useState, useRef } from 'react';
import {
  View, Text, Image, TouchableOpacity, FlatList,
  Dimensions, StyleSheet, ImageBackground,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, radius, typography } from '../theme/colors';
import { jellyfin } from '../services/jellyfinApi';

const { width } = Dimensions.get('window');
const HERO_HEIGHT = width * 1.4;

export default function HeroCarousel({ items, onPlay, onAddToList }) {
  const [activeIndex, setActiveIndex] = useState(0);
  const flatListRef = useRef(null);

  const onViewableItemsChanged = useRef(({ viewableItems }) => {
    if (viewableItems[0]) setActiveIndex(viewableItems[0].index);
  }).current;

  if (!items || items.length === 0) return null;

  const renderItem = ({ item }) => {
    const backdrop = jellyfin.backdropUrl(item.Id) || jellyfin.imageUrl(item.Id);
    const genres = (item.Genres || []).slice(0, 4).join(' • ');

    return (
      <ImageBackground
        source={{ uri: backdrop }}
        style={styles.hero}
        resizeMode="cover"
      >
        <LinearGradient
          colors={['transparent', 'rgba(10,10,10,0.6)', colors.bg]}
          locations={[0, 0.55, 1]}
          style={styles.gradient}
        >
          {/* Chilli flag badge */}
          <View style={styles.brandBadge}>
            <Text style={styles.brandText}>CHILLI</Text>
            <View style={styles.flexDot} />
            <Text style={styles.brandText}>FLEX</Text>
          </View>

          {/* Bottom content */}
          <View style={styles.bottomContent}>
            <Text style={styles.title} numberOfLines={2}>
              {item.Name?.toUpperCase()}
            </Text>

            {genres ? (
              <Text style={styles.genres}>{genres}</Text>
            ) : null}

            <View style={styles.buttonRow}>
              <TouchableOpacity
                style={[styles.btn, styles.btnPlay]}
                onPress={() => onPlay?.(item)}
                activeOpacity={0.85}
              >
                <Ionicons name="play" size={20} color={colors.btnPrimaryText} />
                <Text style={styles.btnPlayText}>Play</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.btn, styles.btnSecondary]}
                onPress={() => onAddToList?.(item)}
                activeOpacity={0.85}
              >
                <Ionicons name="add" size={22} color={colors.text} />
                <Text style={styles.btnSecondaryText}>My List</Text>
              </TouchableOpacity>
            </View>
          </View>
        </LinearGradient>
      </ImageBackground>
    );
  };

  return (
    <View>
      <FlatList
        ref={flatListRef}
        data={items}
        renderItem={renderItem}
        keyExtractor={(it) => it.Id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onViewableItemsChanged={onViewableItemsChanged}
        viewabilityConfig={{ itemVisiblePercentThreshold: 60 }}
      />
      {/* Dot indicators */}
      <View style={styles.dotsRow}>
        {items.map((_, i) => (
          <View
            key={i}
            style={[
              styles.dot,
              i === activeIndex && styles.dotActive,
            ]}
          />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  hero: {
    width,
    height: HERO_HEIGHT,
    justifyContent: 'flex-end',
  },
  gradient: {
    flex: 1,
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xxl,
    paddingBottom: spacing.lg,
  },
  brandBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(0,0,0,0.4)',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.chilli,
  },
  brandText: {
    color: colors.text,
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 2,
  },
  flexDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.chilli,
    marginHorizontal: spacing.sm,
  },
  bottomContent: {
    gap: spacing.md,
  },
  title: {
    color: colors.text,
    fontSize: 36,
    fontWeight: '900',
    letterSpacing: 1.5,
    textShadowColor: 'rgba(0,0,0,0.6)',
    textShadowRadius: 8,
  },
  genres: {
    color: colors.textDim,
    fontSize: 13,
    letterSpacing: 0.5,
    fontWeight: '500',
  },
  buttonRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  btn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: radius.sm,
    flex: 1,
    gap: spacing.sm,
  },
  btnPlay: {
    backgroundColor: colors.btnPrimary,
  },
  btnPlayText: {
    color: colors.btnPrimaryText,
    fontWeight: '700',
    fontSize: 16,
  },
  btnSecondary: {
    backgroundColor: colors.btnSecondary,
  },
  btnSecondaryText: {
    color: colors.btnSecondaryText,
    fontWeight: '600',
    fontSize: 16,
  },
  dotsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    position: 'absolute',
    bottom: spacing.sm,
    left: 0,
    right: 0,
    gap: 6,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  dotActive: {
    backgroundColor: colors.chilli,
    width: 18,
  },
});
