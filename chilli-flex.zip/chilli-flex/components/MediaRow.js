import React from 'react';
import {
  View, Text, Image, TouchableOpacity, FlatList, StyleSheet,
} from 'react-native';
import { colors, spacing, radius } from '../theme/colors';
import { jellyfin } from '../services/jellyfinApi';

export default function MediaRow({ title, items, onItemPress, showProgress = false }) {
  if (!items || items.length === 0) return null;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{title}</Text>
        <View style={styles.titleAccent} />
      </View>

      <FlatList
        data={items}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.Id}
        contentContainerStyle={styles.row}
        renderItem={({ item }) => (
          <MediaCard
            item={item}
            onPress={() => onItemPress?.(item)}
            showProgress={showProgress}
          />
        )}
      />
    </View>
  );
}

function MediaCard({ item, onPress, showProgress }) {
  const imageUrl = jellyfin.imageUrl(item.Id, 'Primary', { maxHeight: 600 });
  const progress = item.UserData?.PlayedPercentage || 0;

  return (
    <TouchableOpacity
      style={styles.card}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <Image
        source={{ uri: imageUrl }}
        style={styles.poster}
        resizeMode="cover"
      />
      {showProgress && progress > 0 && (
        <View style={styles.progressContainer}>
          <View style={styles.progressBg}>
            <View
              style={[styles.progressFill, { width: `${progress}%` }]}
            />
          </View>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: spacing.md,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
    gap: spacing.sm,
  },
  title: {
    color: colors.text,
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  titleAccent: {
    width: 24,
    height: 3,
    backgroundColor: colors.chilli,
    borderRadius: 2,
  },
  row: {
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
  },
  card: {
    width: 130,
    marginRight: spacing.sm,
  },
  poster: {
    width: 130,
    height: 195,
    borderRadius: radius.md,
    backgroundColor: colors.bgElevated,
  },
  progressContainer: {
    position: 'absolute',
    bottom: 8,
    left: 8,
    right: 8,
  },
  progressBg: {
    height: 3,
    backgroundColor: colors.progressBg,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.progressFill,
  },
});
