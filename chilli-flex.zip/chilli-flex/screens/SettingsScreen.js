import React, { useEffect, useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  Alert, ScrollView, KeyboardAvoidingView, Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, radius } from '../theme/colors';
import { jellyfin } from '../services/jellyfinApi';

export default function SettingsScreen({ navigation }) {
  const [serverUrl, setServerUrl] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [userId, setUserId] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      await jellyfin.init();
      setServerUrl(jellyfin.serverUrl || '');
      setApiKey(jellyfin.apiKey || '');
      setUserId(jellyfin.userId || '');
    })();
  }, []);

  const save = async () => {
    if (!serverUrl || !apiKey || !userId) {
      Alert.alert('Missing info', 'All three fields are required.');
      return;
    }
    setSaving(true);
    try {
      await jellyfin.configure({ serverUrl, apiKey, userId });
      // Test connection
      await jellyfin.getLibraries();
      Alert.alert('Connected', 'Chilli Flex is linked to your server.', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch (e) {
      Alert.alert('Connection failed', e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </TouchableOpacity>
          <Text style={styles.heading}>SERVER</Text>
          <View style={styles.headingAccent} />
        </View>

        <Text style={styles.label}>Server URL</Text>
        <TextInput
          style={styles.input}
          value={serverUrl}
          onChangeText={setServerUrl}
          placeholder="http://192.168.1.50:8096"
          placeholderTextColor={colors.textMuted}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="url"
        />

        <Text style={styles.label}>API Key</Text>
        <TextInput
          style={styles.input}
          value={apiKey}
          onChangeText={setApiKey}
          placeholder="Generate in Jellyfin → Dashboard → API Keys"
          placeholderTextColor={colors.textMuted}
          autoCapitalize="none"
          autoCorrect={false}
          secureTextEntry
        />

        <Text style={styles.label}>User ID</Text>
        <TextInput
          style={styles.input}
          value={userId}
          onChangeText={setUserId}
          placeholder="Your Jellyfin user ID (UUID)"
          placeholderTextColor={colors.textMuted}
          autoCapitalize="none"
          autoCorrect={false}
        />

        <TouchableOpacity
          style={styles.saveBtn}
          onPress={save}
          disabled={saving}
          activeOpacity={0.85}
        >
          <Text style={styles.saveBtnText}>
            {saving ? 'CONNECTING...' : 'CONNECT'}
          </Text>
        </TouchableOpacity>

        <View style={styles.helpBox}>
          <Ionicons name="information-circle" size={18} color={colors.ember} />
          <Text style={styles.helpText}>
            Find your User ID in Jellyfin → Dashboard → Users → click your user → check the URL for the UUID.
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  content: { padding: spacing.lg, paddingTop: spacing.xxl + spacing.md },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.xl,
  },
  heading: {
    color: colors.text,
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: 2,
  },
  headingAccent: {
    width: 24,
    height: 3,
    backgroundColor: colors.chilli,
    borderRadius: 2,
  },
  label: {
    color: colors.textDim,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1,
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },
  input: {
    backgroundColor: colors.bgElevated,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    color: colors.text,
    fontSize: 15,
    borderWidth: 1,
    borderColor: colors.border,
  },
  saveBtn: {
    backgroundColor: colors.chilli,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    alignItems: 'center',
    marginTop: spacing.xl,
  },
  saveBtnText: {
    color: colors.text,
    fontWeight: '900',
    fontSize: 16,
    letterSpacing: 2,
  },
  helpBox: {
    flexDirection: 'row',
    backgroundColor: colors.bgElevated,
    padding: spacing.md,
    borderRadius: radius.md,
    marginTop: spacing.xl,
    gap: spacing.sm,
    borderLeftWidth: 3,
    borderLeftColor: colors.ember,
  },
  helpText: {
    flex: 1,
    color: colors.textDim,
    fontSize: 13,
    lineHeight: 18,
  },
});
