import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, ActivityIndicator,
  TouchableOpacity, RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, radius } from '../theme/colors';
import { jellyfin } from '../services/jellyfinApi';
import HeroCarousel from '../components/HeroCarousel';
import MediaRow from '../components/MediaRow';

export default function HomeScreen({ navigation }) {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [featured, setFeatured] = useState([]);
  const [continueWatching, setContinueWatching] = useState([]);
  const [libraries, setLibraries] = useState([]);
  const [libraryRows, setLibraryRows] = useState({});
  const [error, setError] = useState(null);

  const loadData = async () => {
    try {
      await jellyfin.init();

      if (!jellyfin.isConfigured()) {
        setError('Server not configured. Tap Settings to connect to Jellyfin.');
        setLoading(false);
        return;
      }

      const [feat, cont, libs] = await Promise.all([
        jellyfin.getFeatured(5),
        jellyfin.getContinueWatching(),
        jellyfin.getLibraries(),
      ]);

      setFeatured(feat);
      setContinueWatching(cont);
      setLibraries(libs);

      // Load latest items per library
      const rows = {};
      await Promise.all(
        libs.map(async (lib) => {
          const items = await jellyfin.getLatestByCategory(lib.Id, 20);
          rows[lib.Id] = items;
        })
      );
      setLibraryRows(rows);
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { loadData(); }, []);

  const onRefresh = () => {
    setRefreshing(true);
    loadData();
  };

  const handleItemPress = (item) => {
    navigation.navigate('Detail', { itemId: item.Id });
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.chilli} />
        <Text style={styles.loadingText}>Loading library...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Ionicons name="warning" size={48} color={colors.chilli} />
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity
          style={styles.settingsBtn}
          onPress={() => navigation.navigate('Settings')}
        >
          <Text style={styles.settingsBtnText}>Open Settings</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          tintColor={colors.chilli}
        />
      }
    >
      <HeroCarousel
        items={featured}
        onPlay={handleItemPress}
        onAddToList={(item) => console.log('Add to list:', item.Name)}
      />

      {continueWatching.length > 0 && (
        <MediaRow
          title="Continue Watching"
          items={continueWatching}
          onItemPress={handleItemPress}
          showProgress
        />
      )}

      {libraries.map((lib) => (
        <MediaRow
          key={lib.Id}
          title={`Latest in ${lib.Name}`}
          items={libraryRows[lib.Id] || []}
          onItemPress={handleItemPress}
        />
      ))}

      <View style={{ height: spacing.xxl }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  center: {
    flex: 1,
    backgroundColor: colors.bg,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
    gap: spacing.md,
  },
  loadingText: {
    color: colors.textDim,
    fontSize: 14,
    letterSpacing: 0.5,
  },
  errorText: {
    color: colors.text,
    fontSize: 16,
    textAlign: 'center',
    marginVertical: spacing.md,
  },
  settingsBtn: {
    backgroundColor: colors.chilli,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderRadius: radius.sm,
  },
  settingsBtnText: {
    color: colors.text,
    fontWeight: '700',
    fontSize: 16,
  },
});
