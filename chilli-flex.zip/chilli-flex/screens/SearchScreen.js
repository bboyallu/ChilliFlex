import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, TextInput, FlatList, TouchableOpacity, Image,
  StyleSheet, ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, radius } from '../theme/colors';
import { jellyfin } from '../services/jellyfinApi';

export default function SearchScreen({ navigation }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  // Debounced search
  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    const t = setTimeout(async () => {
      setLoading(true);
      try {
        const items = await jellyfin.search(query);
        setResults(items);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }, 350);
    return () => clearTimeout(t);
  }, [query]);

  const renderItem = useCallback(({ item }) => (
    <TouchableOpacity
      style={styles.resultCard}
      onPress={() => navigation.navigate('Detail', { itemId: item.Id })}
      activeOpacity={0.8}
    >
      <Image
        source={{ uri: jellyfin.imageUrl(item.Id, 'Primary', { maxHeight: 400 }) }}
        style={styles.poster}
      />
      <View style={styles.resultInfo}>
        <Text style={styles.resultTitle} numberOfLines={2}>{item.Name}</Text>
        <Text style={styles.resultMeta}>
          {item.Type} {item.ProductionYear ? `• ${item.ProductionYear}` : ''}
        </Text>
        {item.Genres?.length > 0 && (
          <Text style={styles.resultGenres} numberOfLines={1}>
            {item.Genres.slice(0, 3).join(' • ')}
          </Text>
        )}
      </View>
    </TouchableOpacity>
  ), [navigation]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.heading}>SEARCH</Text>
        <View style={styles.headingAccent} />
      </View>

      <View style={styles.searchBar}>
        <Ionicons name="search" size={20} color={colors.textDim} />
        <TextInput
          style={styles.input}
          value={query}
          onChangeText={setQuery}
          placeholder="Movies, shows, genres..."
          placeholderTextColor={colors.textMuted}
          autoCorrect={false}
          autoCapitalize="none"
        />
        {query.length > 0 && (
          <TouchableOpacity onPress={() => setQuery('')}>
            <Ionicons name="close-circle" size={20} color={colors.textDim} />
          </TouchableOpacity>
        )}
      </View>

      {loading && (
        <ActivityIndicator
          style={{ marginTop: spacing.lg }}
          size="small"
          color={colors.chilli}
        />
      )}

      {!loading && query.length > 0 && results.length === 0 && (
        <Text style={styles.empty}>No results for "{query}"</Text>
      )}

      <FlatList
        data={results}
        renderItem={renderItem}
        keyExtractor={(it) => it.Id}
        contentContainerStyle={styles.list}
        keyboardShouldPersistTaps="handled"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bg,
    paddingTop: spacing.xl,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  heading: {
    color: colors.text,
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: 2,
  },
  headingAccent: {
    width: 32,
    height: 4,
    backgroundColor: colors.chilli,
    borderRadius: 2,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bgElevated,
    marginHorizontal: spacing.lg,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    gap: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  input: {
    flex: 1,
    color: colors.text,
    paddingVertical: spacing.md,
    fontSize: 15,
  },
  empty: {
    color: colors.textDim,
    textAlign: 'center',
    marginTop: spacing.xl,
    fontSize: 14,
  },
  list: {
    paddingVertical: spacing.lg,
  },
  resultCard: {
    flexDirection: 'row',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    gap: spacing.md,
  },
  poster: {
    width: 80,
    height: 120,
    borderRadius: radius.sm,
    backgroundColor: colors.bgElevated,
  },
  resultInfo: {
    flex: 1,
    justifyContent: 'center',
    gap: 4,
  },
  resultTitle: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
  },
  resultMeta: {
    color: colors.chilli,
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  resultGenres: {
    color: colors.textDim,
    fontSize: 12,
  },
});
