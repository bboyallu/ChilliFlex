import React, { useEffect, useState } from 'react';
import {
  View, Text, FlatList, Image, TouchableOpacity, StyleSheet,
  ActivityIndicator, RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, radius } from '../theme/colors';
import { jellyfin } from '../services/jellyfinApi';

export default function NewsScreen({ navigation }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    try {
      const feed = await jellyfin.getNewsFeed(25);
      setItems(feed);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { load(); }, []);

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  const formatDate = (iso) => {
    if (!iso) return 'Recently';
    const d = new Date(iso);
    const days = Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days} days ago`;
    return d.toLocaleDateString();
  };

  const renderItem = ({ item, index }) => {
    const backdrop = jellyfin.backdropUrl(item.Id) || jellyfin.imageUrl(item.Id);
    const isFirst = index === 0;

    return (
      <TouchableOpacity
        style={[styles.card, isFirst && styles.cardFeatured]}
        onPress={() => navigation.navigate('Detail', { itemId: item.Id })}
        activeOpacity={0.9}
      >
        <Image
          source={{ uri: backdrop }}
          style={[styles.backdrop, isFirst && styles.backdropFeatured]}
        />
        <LinearGradient
          colors={['transparent', 'rgba(10,10,10,0.95)']}
          style={styles.cardGradient}
        >
          <View style={styles.dateRow}>
            <View style={styles.newBadge}>
              <View style={styles.pulseDot} />
              <Text style={styles.newBadgeText}>JUST ADDED</Text>
            </View>
            <Text style={styles.dateText}>{formatDate(item.DateCreated)}</Text>
          </View>

          <Text style={styles.cardTitle} numberOfLines={2}>{item.Name}</Text>

          {item.Genres?.length > 0 && (
            <Text style={styles.cardGenres}>
              {item.Genres.slice(0, 3).join(' • ')}
            </Text>
          )}

          {item.Overview && (
            <Text style={styles.cardOverview} numberOfLines={isFirst ? 4 : 2}>
              {item.Overview}
            </Text>
          )}

          <View style={styles.cardActions}>
            <TouchableOpacity style={styles.playBtn}>
              <Ionicons name="play" size={16} color={colors.btnPrimaryText} />
              <Text style={styles.playBtnText}>Watch Now</Text>
            </TouchableOpacity>
          </View>
        </LinearGradient>
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.chilli} />
      </View>
    );
  }

  return (
    <FlatList
      style={styles.container}
      data={items}
      renderItem={renderItem}
      keyExtractor={(it) => it.Id}
      ListHeaderComponent={
        <View style={styles.header}>
          <Text style={styles.heading}>NEWS</Text>
          <View style={styles.headingAccent} />
          <Text style={styles.subheading}>Fresh drops in your library</Text>
        </View>
      }
      contentContainerStyle={{ paddingBottom: spacing.xxl }}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          tintColor={colors.chilli}
        />
      }
    />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  center: {
    flex: 1,
    backgroundColor: colors.bg,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xxl + spacing.md,
    paddingBottom: spacing.lg,
  },
  heading: {
    color: colors.text,
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: 2,
  },
  headingAccent: {
    width: 32,
    height: 4,
    backgroundColor: colors.chilli,
    borderRadius: 2,
    marginTop: 4,
  },
  subheading: {
    color: colors.textDim,
    fontSize: 13,
    marginTop: spacing.sm,
    letterSpacing: 0.5,
  },
  card: {
    marginHorizontal: spacing.lg,
    marginBottom: spacing.md,
    borderRadius: radius.lg,
    overflow: 'hidden',
    backgroundColor: colors.bgElevated,
    height: 220,
  },
  cardFeatured: {
    height: 320,
    borderWidth: 1,
    borderColor: colors.chilli,
  },
  backdrop: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  backdropFeatured: {
    opacity: 0.95,
  },
  cardGradient: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: spacing.md,
    gap: 6,
  },
  dateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing.sm,
  },
  newBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.chilli,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.sm,
    gap: 6,
  },
  pulseDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.text,
  },
  newBadgeText: {
    color: colors.text,
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 1,
  },
  dateText: {
    color: colors.textDim,
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  cardTitle: {
    color: colors.text,
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  cardGenres: {
    color: colors.ember,
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  cardOverview: {
    color: colors.textDim,
    fontSize: 13,
    lineHeight: 18,
    marginTop: 4,
  },
  cardActions: {
    flexDirection: 'row',
    marginTop: spacing.sm,
  },
  playBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.btnPrimary,
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
    borderRadius: radius.sm,
    gap: 6,
  },
  playBtnText: {
    color: colors.btnPrimaryText,
    fontWeight: '700',
    fontSize: 13,
  },
});
