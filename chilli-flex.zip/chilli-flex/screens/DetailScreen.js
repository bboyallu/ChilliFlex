import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, ImageBackground, TouchableOpacity,
  StyleSheet, ActivityIndicator, Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, radius } from '../theme/colors';
import { jellyfin } from '../services/jellyfinApi';

const { width } = Dimensions.get('window');

export default function DetailScreen({ route, navigation }) {
  const { itemId } = route.params;
  const [item, setItem] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const data = await jellyfin.getItem(itemId);
        setItem(data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, [itemId]);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.chilli} />
      </View>
    );
  }

  if (!item) return null;

  const backdrop = jellyfin.backdropUrl(item.Id) || jellyfin.imageUrl(item.Id);
  const runtime = item.RunTimeTicks
    ? Math.round(item.RunTimeTicks / 600000000)
    : null;

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <ImageBackground source={{ uri: backdrop }} style={styles.hero}>
        <LinearGradient
          colors={['rgba(10,10,10,0.4)', 'transparent', colors.bg]}
          locations={[0, 0.4, 1]}
          style={styles.heroGradient}
        >
          <TouchableOpacity
            style={styles.backBtn}
            onPress={() => navigation.goBack()}
          >
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </TouchableOpacity>
        </LinearGradient>
      </ImageBackground>

      <View style={styles.content}>
        <Text style={styles.title}>{item.Name}</Text>

        <View style={styles.metaRow}>
          {item.ProductionYear && (
            <Text style={styles.meta}>{item.ProductionYear}</Text>
          )}
          {runtime && <Text style={styles.meta}>{runtime} min</Text>}
          {item.OfficialRating && (
            <View style={styles.ratingBadge}>
              <Text style={styles.ratingText}>{item.OfficialRating}</Text>
            </View>
          )}
          {item.CommunityRating && (
            <View style={styles.starRow}>
              <Ionicons name="star" size={14} color={colors.ember} />
              <Text style={styles.meta}>{item.CommunityRating.toFixed(1)}</Text>
            </View>
          )}
        </View>

        <View style={styles.btnRow}>
          <TouchableOpacity style={[styles.btn, styles.btnPlay]}>
            <Ionicons name="play" size={20} color={colors.btnPrimaryText} />
            <Text style={styles.btnPlayText}>Play</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.btn, styles.btnSec]}>
            <Ionicons name="add" size={22} color={colors.text} />
            <Text style={styles.btnSecText}>My List</Text>
          </TouchableOpacity>
        </View>

        {item.Overview && (
          <Text style={styles.overview}>{item.Overview}</Text>
        )}

        {item.Genres?.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>GENRES</Text>
            <View style={styles.genreRow}>
              {item.Genres.map((g) => (
                <View key={g} style={styles.genreChip}>
                  <Text style={styles.genreText}>{g}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {item.People?.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>CAST & CREW</Text>
            <Text style={styles.castText}>
              {item.People.slice(0, 6).map((p) => p.Name).join(', ')}
            </Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  center: {
    flex: 1, backgroundColor: colors.bg,
    justifyContent: 'center', alignItems: 'center',
  },
  hero: { width, height: width * 0.75 },
  heroGradient: { flex: 1, padding: spacing.md },
  backBtn: {
    width: 40, height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: spacing.lg,
  },
  content: { padding: spacing.lg, marginTop: -spacing.xxl },
  title: {
    color: colors.text,
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginTop: spacing.sm,
    flexWrap: 'wrap',
  },
  meta: { color: colors.textDim, fontSize: 14, fontWeight: '600' },
  ratingBadge: {
    borderWidth: 1,
    borderColor: colors.textDim,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: radius.sm,
  },
  ratingText: { color: colors.textDim, fontSize: 11, fontWeight: '700' },
  starRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  btnRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  btn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: radius.sm,
    gap: spacing.sm,
  },
  btnPlay: { backgroundColor: colors.btnPrimary },
  btnPlayText: { color: colors.btnPrimaryText, fontWeight: '700', fontSize: 16 },
  btnSec: { backgroundColor: colors.btnSecondary },
  btnSecText: { color: colors.text, fontWeight: '600', fontSize: 16 },
  overview: {
    color: colors.text,
    fontSize: 14,
    lineHeight: 22,
    marginTop: spacing.lg,
  },
  section: { marginTop: spacing.lg },
  sectionLabel: {
    color: colors.chilli,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 2,
    marginBottom: spacing.sm,
  },
  genreRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  genreChip: {
    backgroundColor: colors.bgElevated,
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
  },
  genreText: { color: colors.text, fontSize: 12, fontWeight: '600' },
  castText: { color: colors.textDim, fontSize: 14, lineHeight: 20 },
});
